import xbmcaddon

MainBase = 'https://pd1bertv.000webhostapp.com/files/file/home.txt'
addon = xbmcaddon.Addon('plugin.video.PD1BER_TV')